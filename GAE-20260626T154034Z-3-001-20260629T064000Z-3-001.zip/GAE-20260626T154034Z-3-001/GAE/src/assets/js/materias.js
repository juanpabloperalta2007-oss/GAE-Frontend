document.addEventListener("DOMContentLoaded", function() {

    const formulario = document.getElementById("formMaterias");
    const inputMateria = document.getElementById("nombreMateria");
    const selectEstado = document.getElementById("estadoMateria");
    const botonLimpiar = document.getElementById("btnLimpiar");

    
    if (formulario) {
        formulario.addEventListener("submit", function(evento) {
            evento.preventDefault(); 


            const nombre = inputMateria.value;
            const estado = selectEstado.value;

            
            if (nombre === "" || estado === "") {
                alert("Por favor, completa todos los campos");
            } else {
                let listaMaterias = JSON.parse(localStorage.getItem("misMaterias")) || [];

                const nuevaMateria = {
                    nombre: nombre,
                    estado: estado
                };

                listaMaterias.push(nuevaMateria);
                localStorage.setItem("misMaterias", JSON.stringify(listaMaterias));

                alert("Materia guardada con éxito");
                formulario.reset(); 
            }
        });
    }

    if (botonLimpiar) {
        botonLimpiar.addEventListener("click", function() {
            formulario.reset();
        });
    }

 // Mostrar las materias registradas en la tablaMaterias       
const tabla = document.getElementById("tablaMaterias");

//obtiene la lista de materias desde el localStorage
if (tabla) {
    let listaMaterias = JSON.parse(localStorage.getItem("misMaterias")) || [];

    //limpia la tabla antes de llenarla con los datos
    tabla.innerHTML = "";
    
    //recorre la lista de materias y agrega cada materia a la tabla
    listaMaterias.forEach((materia, index) => {
        //agrega una fila a la tabla con los datos de la materia
        tabla.innerHTML += `
            <tr>
                <td>${materia.nombre}</td>
                <td>${materia.estado == "1" ? "Activo" : "Inactivo"}</td>
                <td>${index + 1}</td>
                <td>
                    <button class="btn btn-warning btn-sm">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminarMateria(${index})">
                        Eliminar
                    </button>
                </td>
            </tr>
        `;
    });
}
});
function eliminarMateria(indice) {

    let listaMaterias = JSON.parse(localStorage.getItem("misMaterias")) || [];

    // Elimina la materia del arreglo de la posición especificada por el índice
    listaMaterias.splice(indice, 1);

    // Actualiza el localStorage con la nueva lista de materias
    localStorage.setItem("misMaterias", JSON.stringify(listaMaterias));

    location.reload();

}
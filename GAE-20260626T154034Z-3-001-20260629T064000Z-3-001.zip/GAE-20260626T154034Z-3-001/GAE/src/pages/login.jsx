function login(){
    return (
<div className="container d-flex justify-content-center align-items-center vh-100">
  
  <div className="card shadow-lg" style="max-width: 400px; width: 100%;">
    
    <div className="card-header bg-primary text-white text-center">
      <h4 className="mb-0">Iniciar Sesión</h4>
    </div>

    <div className="card-body">
      
          <form action="#exito">

        <div className="mb-3">
          <label className="form-label">Correo electrónico</label>
          <input type="email" className="form-control" placeholder="ejemplo@email.com">
        </div>

        <div class="mb-3">
          <label className="form-label">Contraseña</label>
          <input type="password" class="form-control" placeholder="********">
        </div>

        <div class="d-grid gap-2">
          <button type="submit" class="btn btn-success btn-lg">
            Iniciar Sesión
          </button>

          <a href="registro.html" class="btn btn-outline-secondary">
            Registrar
          </a>
        </div>

      </form>

      <div id="exito" class="alert alert-success mt-4 text-center fw-bold shadow-sm rounded">
    
      </div>

    </div>

  </div>

</div>

    )
}

export default login